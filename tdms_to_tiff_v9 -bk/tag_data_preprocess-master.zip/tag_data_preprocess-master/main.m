clear;close all;clc;
addpath('.\correct_yaxis\');
addpath('.\time_corr\'); 
addpath('.\reslice\');
%--------------------------------------------------------------------------
%% sorting 3D
% ch1 folder start/final image name
ALL_first = 3328;
last = 12479; 
% define by your FOV rangea and tag samples
FOV = "400*400";
x_pixel = 128;  
y_pixel = 128; 
z_pixel = 265; 
% reconstruct data
shift_pixel = 0;
updown_or_downup = "downup"; % updown or downup, which means the order of y-axis image take by galvo
% input/output dir name
s1 = 'C:\Users\NTHU_dail\108011217\chung20220722\FLB3 4 4 128 128 10s\export\'; 
s4 = 'C:\Users\NTHU_dail\108011217\chung20220722\FLB3 4 4 128 128 10s\ch1_out\'; 
%save 4D stack
save_rawmat = 1; % if true save, else not save
output_rawdata_filename = "C:\Users\NTHU_dail\108011217\chung20220722\FLB3 4 4 128 128 10s\export_out.mat";
% run
Sorting_3D_20200817_test;
%--------------------------------------------------------------------------
%% time correction
% run
xyzt_raw_data_timecorr = TAG_preprocessing(xyzt_raw_data);
%--------------------------------------------------------------------------
%% reslice
% save_type: how to process the data, "interpolate" or "mean"
% method: how to reslice, "z"(height) or "layer"
save_type = "interpolate";
method = "z";
% z-axis resample
if method == "z"
    N_z = 5; % N_z = z resolution
    z_axis_resample(method,N_z);
elseif method == "layer"
    N_layer = 50; % "N_layer" layers turn into 1 stack.
    z_axis_resample(method,N_layer);
end
% run
xyzt_reslice_timecorr = reslice(xyzt_raw_data_timecorr,save_type);
% save raw data
output_path = "C:\Users\NTHU_dail\108011217\chung20220722\FLB3 4 4 128 128 10s\"; %assign the output path
output_reslice_filename = "reslice.mat";
save(output_path+output_reslice_filename,"xyzt_reslice_timecorr","-v7.3")
%--------------------------------------------------------------------------
%% extract data from raw stack
% xyt: output x-y-t stack in ./ch1_out_xyt dir, using 1(save), 0(don't save)
% xyz: output x-y-z stack in ./ch1_out_xyz dir, using 1(save), 0(don't save)
xyt = 1;
xyz = 1;
% run
extract_data_from_raw_stack(xyzt_reslice_timecorr,xyt,xyz,output_path);
disp("all done")
